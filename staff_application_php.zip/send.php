<?php
$to = "ghost.vr1091@yahoo.com";
$subject = "New Discord Staff Application";

$message = "
Discord Username: " . $_POST['username'] . "\n
Age: " . $_POST['age'] . "\n
Reason: " . $_POST['reason'] . "\n
Experience: " . $_POST['experience'] . "\n
Experience Details: " . $_POST['exp_details'] . "\n
Weekly Activity: " . $_POST['activity'] . "\n
Extra Info: " . $_POST['extra'] . "\n
";

$headers = "From: no-reply@yourwebsite.com";

mail($to, $subject, $message, $headers);

echo "Application submitted successfully!";
?>
